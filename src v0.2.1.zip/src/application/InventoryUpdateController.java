package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.sql.*;

public class InventoryUpdateController {

	public void openInventoryMain(ActionEvent event) throws Exception{
		Parent inventoryParent = FXMLLoader.load(getClass().getResource("InventoryMain.fxml"));
		Scene inventoryScene = new Scene(inventoryParent,700,900);
		inventoryScene.getStylesheets().add(getClass().getResource("inventoryMain.css").toExternalForm());
		Stage inventoryStage = (Stage)((Node)event.getSource()).getScene().getWindow();
		inventoryStage.setScene(inventoryScene);
		inventoryStage.show();
	}
	public void returnToMain(ActionEvent event) throws Exception{
		Parent mainParent = FXMLLoader.load(getClass().getResource("Main.fxml"));
		Scene mainScene = new Scene(mainParent,700,900);
		mainScene.getStylesheets().add(getClass().getResource("main.css").toExternalForm());
		Stage mainStage = (Stage)((Node)event.getSource()).getScene().getWindow();
		mainStage.setScene(mainScene);
		mainStage.show();
	}
	
	/*public void addToDataBase(int id, String name, String varietal, String region, double price, int vintage) {
		try
	    {
	      // create a mysql database connection
	      String myDriver = "org.gjt.mm.mysql.Driver";
	      String myUrl = "jdbc:mysql://localhost/passion";
	      Class.forName(myDriver);
	      Connection conn = DriverManager.getConnection(myUrl, "root", "mysql");
	      Statement st = conn.createStatement();
	      // note that i'm leaving "date_created" out of this insert statement
	      
	      st.executeUpdate("INSERT INTO " + "wine" + "VALUES (" + id + "," + name + "," + varietal + "," + region + "," + price + "," + vintage + ")");
	      conn.close();
	    }
	    catch (Exception e)
	    {
	      System.err.println("Got an exception!");
	      System.err.println(e.getMessage());
	    }
	}*/
	
	public void addToDataBase() {
		try
	    {
	      // create a mysql database connection
	      String myDriver = "com.mysql.jdbc.Driver";
	      String myUrl = "jdbc:mysql://localhost:3306/passion";
	      Class.forName(myDriver);
	      Connection conn = DriverManager.getConnection(myUrl, "root", "mysql");
	      Statement st = conn.createStatement();
	      // note that i'm leaving "date_created" out of this insert statement
	      
	      st.executeUpdate("Source C:\\spirits.sql");
	      conn.close();
	    }
	    catch (Exception e)
	    {
	      System.err.println("Got an exception!");
	      System.err.println(e.getMessage());
	    }
	}
	
	
	
	
}
