package application.Objects;

public class Liquor extends Product{

	public Liquor(int userID, String userName, double userPrice, String userOrigin, String userType, String userDesc) {
		super(userID, userName, userPrice, userOrigin, userType, userDesc);
	}

}