package application.Objects;

import java.util.LinkedList;

public class Customer {
	private String name;
	private String email;
	private int phone;
	private LinkedList<HistoryItem> history;
	
	public Customer(String userName, String userEmail, int userPhone) {
		name=userName;
		email=userEmail;
		phone=userPhone;
		history = new LinkedList<>();
	}
	
	public void addToHistory(String date, Product prod, int num) {
		history.add(new HistoryItem(date, prod, num));
	}
	
	public LinkedList<HistoryItem> getHistory() {
		return history;
	}
	public void setName(String newName) {
		name=newName;
	}
	public String getName() {
		return name;
	}
	public void setEmail(String newEmail) {
		email=newEmail;
	}
	public String getEmail() {
		return email;
	}
	public void setPhone(int newPhone) {
		phone=newPhone;
	}
	public int getPhone() {
		return phone;
	}
	
}
