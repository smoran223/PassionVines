package application.Objects;

public class Product {
		protected int id;
		protected String name;
		protected double price;
		protected int stock;
		protected String origin;
		protected String type;
		protected String desc;

		public Product(int userID, String userName, double userPrice, String userOrigin, String userType, String userDesc){
			id = userID;
			name = userName;
			price = userPrice;
			stock = 0;
			origin = userOrigin;
			type = userType;
			desc = userDesc;
			//work with database
		}
		
		public void editPrice(double n) {
			if(n<0) {price = n;}
		}
		
		public void increaseStock(int n){
			stock = stock + n;
			//work with database
			//work with interface
		}

		public void decreaseStock(int n){
			if(stock >= n){
				stock = stock - n;}
				//work with database
			//work with interface
			else{
				//Handle error appropriately
				//work with database
				//work with interface
			}
		}
}