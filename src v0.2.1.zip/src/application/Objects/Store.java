package application.Objects;

import java.util.LinkedList;

public class Store{
	private Stock stock;
	private LinkedList<Customer> customers;
	private Pairer pair;
	public Store(){
		stock = new Stock();
		customers = new LinkedList<>();
		pair = new Pairer();
	}
	
	public Stock accessStock() {
		return stock;
	}
	
	public LinkedList<Customer> getCustomers(){
		return customers;
	}
	
	public Pairer getPairer() {
		return pair;
	}
	
	public void addCustomer(String name, String email, int phone) {
		customers.add(new Customer(name, email, phone));
	}
	
	public void removeCustomer(String email) {
		int i = 0;
		while(i < customers.size()) {
			if(customers.get(i).getEmail().equals(email)) {
				customers.remove(i);
				i=customers.size();
			}
			i++;
		}
	}
	
	private class Pairer{
		
	}
	
}
