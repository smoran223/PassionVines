package application.Objects;

import java.util.HashMap;
public class Stock{
	HashMap<Integer, Product> inventory;
	//Amount of different types of products
	int numFood;
	int numBeer;
	int numWine;
	int numLiquor;
	
	public Stock(){
		inventory = new HashMap<>();
		numFood = 0;
		numBeer = 0;
		numWine = 0;
		numLiquor = 0;
	}
	
	public void addProduct(Product prod, int num) {
		inventory.get(prod.id).increaseStock(num);
	}
	
	public void removeProduct(Product prod, int num) {
		inventory.get(prod.id).decreaseStock(num);
	}
	
	public void addNewProduct(String product, String name, double price, String origin, String type, String desc, int vintage, int stock){
		if(product.equals("Food")){
			inventory.put(numFood,new Food(numFood, name, price, origin, type, desc));
			inventory.get(numFood).stock = stock;
			numFood++;
			//Work with database
		}
		else if(product.equals("Beer")){
			inventory.put(numBeer+100,new Beer(numBeer+100, name, price, origin, type, desc));
			inventory.get(numBeer+100).stock = stock;
			numBeer++;
			//Work with database
		}
		else if(product.equals("Wine")){
			inventory.put(numWine+200,new Wine(numWine+200, name, price, origin, type, desc, vintage));
			inventory.get(numWine+200).stock = stock;
			numWine++;
			//Work with database
		}
		else{
			inventory.put(numLiquor+300,new Liquor(numLiquor+300, name, price, origin, type, desc));
			inventory.get(numLiquor+300).stock = stock;
			numLiquor++;
			//Work with database
		}
	}
}