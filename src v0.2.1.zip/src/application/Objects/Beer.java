package application.Objects;

public class Beer extends Product{

	public Beer(int userID, String userName, double userPrice, String userOrigin, String userType, String userDesc) {
		super(userID, userName, userPrice, userOrigin, userType, userDesc);
	}

}