package application.Objects;

public class HistoryItem {
	private String date;
	private Product item;
	private int quantity;
	
	public HistoryItem(String userDate, Product userItem, int userQuantity) {
		date=userDate;
		item=userItem;
		quantity=userQuantity;
	}
	
	public String getDate() {
		return date;
	}
	
	public Product getItem() {
		return item;
	}
	
	public int getQuantity() {
		return quantity;
	}
}
