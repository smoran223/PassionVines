package application.Objects;

public class Food extends Product{

	public Food(int userID, String userName, double userPrice, String userOrigin, String userType, String userDesc) {
		super(userID, userName, userPrice, userOrigin, userType, userDesc);
	}

}