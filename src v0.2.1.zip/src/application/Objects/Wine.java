package application.Objects;

public class Wine extends Product{
	
	protected int vintage;
	public Wine(int userID, String userName, double userPrice, String userOrigin, String userType, String userDesc, int userVintage) {
		super(userID, userName, userPrice, userOrigin, userType, userDesc);
		vintage = userVintage;
	}

}